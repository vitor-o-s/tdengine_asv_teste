package com.taosdata;

import com.taosdata.jdbc.tmq.ReferenceDeserializer;

public class BeanDeserializer extends ReferenceDeserializer<Bean> {
}
